
import pandas as pd
import matplotlib.pyplot as plt

# 读取数据集
data = pd.read_csv("Wimbledon_featured_matches.csv")

# 筛选一场比赛，可以根据实际情况选择其他比赛
match_data = data[data['match_id'] == '2023-wimbledon-1701']

# 初始化变量
player1_points_won = 0
player2_points_won = 0
player1_wins = 0
player2_wins = 0
player1_points = []
player2_points = []
point_differences = []
serve_indicator = []
winning_prob_player1 = []



def get_mixed_time_intervals(match_id):
    # 读取数据集
    data = pd.read_csv("Wimbledon_featured_matches.csv")

    # 筛选指定比赛的数据
    match_data = data[data['match_id'] == match_id]

    # 初始化变量
    time_intervals = []
    last_point_time = {'player1': None, 'player2': None}

    # 遍历比赛数据，计算每次得分距离相同玩家上一次得分的时间
    for index, row in match_data.iterrows():
        if row['point_victor'] == 1:
            player_name = row['player1']
            opponent_name = row['player2']
        elif row['point_victor'] == 2:
            player_name = row['player2']
            opponent_name = row['player1']
        else:
            continue

        if last_point_time[player_name] is None:
            last_point_time[player_name] = row['elapsed_time']
            time_intervals.append({'player': player_name, 'opponent': opponent_name, 'time_interval': 0})
        else:
            time_interval = row['elapsed_time'] - last_point_time[player_name]
            time_intervals.append({'player': player_name, 'opponent': opponent_name, 'time_interval': time_interval})
            last_point_time[player_name] = row['elapsed_time']

    return time_intervals



# 遍历比赛数据，计算每个点数后两位选手的得分、比分差和胜率曲线
for index, row in match_data.iterrows():
    if row['point_victor'] == 1:
        player1_points_won += 1
    elif row['point_victor'] == 2:
        player2_points_won += 1

    player1_points.append(player1_points_won)
    player2_points.append(player2_points_won)
    point_differences.append(player1_points_won - player2_points_won)
    serve_indicator.append(row['server'])

    if row['set_victor'] == 1:  # Player 1 wins the set
        player1_wins += 1
    elif row['set_victor'] == 2:  # Player 2 wins the set
        player2_wins += 1

    total_sets = player1_wins + player2_wins
    total_points = player1_points_won + player2_points_won

    # 计算胜率曲线（在每个点之前）
    winning_prob_player1.append(player1_wins / total_sets if total_sets > 0 else 0)

# 分图显示比赛流程
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, sharex=True, figsize=(12, 14))

# 绘制比分差图
ax1.plot(point_differences, label='Point Difference (Player 1 - Player 2)', linestyle='-', marker='o', color='blue')
ax1.set_ylabel('Point Difference')
ax1.legend()

# 标出先发球的选手
for i, serve in enumerate(serve_indicator):
    if serve == 1:
        ax1.axvline(x=i, color='green', linestyle='--', linewidth=0.5)
    elif serve == 2:
        ax1.axvline(x=i, color='red', linestyle='--', linewidth=0.5)

# 绘制比分折线
ax2.plot(player1_points, label='Player 1 - Points', linestyle='--', marker='o', color='green')
ax2.plot(player2_points, label='Player 2 - Points', linestyle='--', marker='o', color='red')
ax2.set_ylabel('Points')
ax2.legend()

# 绘制胜率曲线
ax3.plot(winning_prob_player1, label='Player 1 - Winning Probability', linestyle='-', marker='o', color='black')
ax3.set_xlabel('Points')
ax3.set_ylabel('Winning Probability')
ax3.legend()

plt.title('Match Flow - Player Performance')
plt.show()