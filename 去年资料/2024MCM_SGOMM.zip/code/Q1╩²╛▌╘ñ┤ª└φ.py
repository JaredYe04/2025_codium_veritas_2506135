import pandas as pd

# 读取数据
df = pd.read_csv("Wimbledon_featured_matches.csv")

# 定性字段映射
winner_shot_type_mapping = {'F': 0, 'B': 1}
serve_width_mapping = {'B': 0, 'BC': 1, 'BW': 2, 'C': 3, 'W': 4}
serve_depth_mapping = {'CTL': 0, 'NCTL': 1}
return_depth_mapping = {'D': 0, 'ND': 1}

score_mapping={"0":"0","15":"1","30":"2","40":"3","AD":"4"}
# 替换定性字段为定量字段
df['winner_shot_type'] = df['winner_shot_type'].map(winner_shot_type_mapping)
df['serve_width'] = df['serve_width'].map(serve_width_mapping)
df['serve_depth'] = df['serve_depth'].map(serve_depth_mapping)
df['return_depth'] = df['return_depth'].map(return_depth_mapping)
df['p1_score'] = df['p1_score'].map(score_mapping)
df['p2_score'] = df['p2_score'].map(score_mapping)
# 显示处理后的数据
print(df.head())

df.fillna(method="ffill", inplace=True)
df.fillna(method="bfill", inplace=True)
df.fillna(method="backfill", inplace=True)

from sklearn.preprocessing import MinMaxScaler

# 选择需要归一化的字段
columns_to_normalize = ['p1_distance_run', 'p2_distance_run', 'rally_count', 'speed_mph']
# 使用MinMaxScaler对选择的字段进行归一化
scaler = MinMaxScaler()
df[columns_to_normalize] = scaler.fit_transform(df[columns_to_normalize])


# 保存处理后的数据
df.to_csv("Wimbledon_featured_matches_processed.csv", index=False)