import pandas as pd


df = pd.read_csv("Wimbledon_featured_matches_processed_with_momentums.csv")

# 创建游戏和盘差异指标
df['games_diff'] = df['p1_games'] - df['p2_games']
df['sets_diff'] = df['p1_sets'] - df['p2_sets']

# 创建发球局差异指标
df['serve_games_diff'] = df.groupby(['match_id', 'server'])['game_victor'].cumsum() * (2 * (df['server'] == 1) - 1)

# 创建得分差异指标
df['score_diff'] = df['p1_points_won'] - df['p2_points_won']

# 创建连胜/连败指标
df['p1_win_streak'] = (df['game_victor'] == 1).groupby(df['match_id']).cumsum()
df['p2_win_streak'] = (df['game_victor'] == 2).groupby(df['match_id']).cumsum()

# 创建速度和距离相关指标
# 例如，你可以使用速度和距离数据创建新的特征，比如速度的均值、距离的累计值等

# 关键点差异指标
df['key_points_diff'] = (df['p1_score'] == 'AD').astype(int) - (df['p2_score'] == 'AD').astype(int)

# 发球效果指标
df['p1_first_serve_points_won'] = (df['point_victor'] == 1) & (df['serve_no'] == 1)
df['p2_first_serve_points_won'] = (df['point_victor'] == 2) & (df['serve_no'] == 1)
df['p1_second_serve_points_won'] = (df['point_victor'] == 1) & (df['serve_no'] == 2)
df['p2_second_serve_points_won'] = (df['point_victor'] == 2) & (df['serve_no'] == 2)
df['p1_ace_percentage'] = df.groupby('match_id')['p1_ace'].transform('mean')
df['p2_ace_percentage'] = df.groupby('match_id')['p2_ace'].transform('mean')
df['p1_double_fault_percentage'] = df.groupby('match_id')['p1_double_fault'].transform('mean')
df['p2_double_fault_percentage'] = df.groupby('match_id')['p2_double_fault'].transform('mean')

# 局时长指标
df['game_duration'] = df.groupby(['match_id', 'set_no', 'game_no'])['elapsed_time'].transform('max')

# 局胜率指标
df['p1_game_win_rate'] = df.groupby(['match_id', 'set_no', 'game_no'])['game_victor'].transform(lambda x: (x == 1).mean())
df['p2_game_win_rate'] = df.groupby(['match_id', 'set_no', 'game_no'])['game_victor'].transform(lambda x: (x == 2).mean())

# 发球方胜率指标
df['server_win_rate'] = df.groupby(['match_id', 'set_no', 'game_no', 'server'])['game_victor'].transform(lambda x: (x == x.iloc[0]).mean())


df.to_csv("deeply_digged_data.csv")

# 筛选需要的特征列
features = ['games_diff', 'sets_diff', 'serve_games_diff', 'score_diff', 'p1_win_streak', 'p2_win_streak',
            'key_points_diff', 'p1_first_serve_points_won', 'p2_first_serve_points_won', 'p1_second_serve_points_won',
            'p2_second_serve_points_won', 'p1_ace_percentage', 'p2_ace_percentage', 'p1_double_fault_percentage',
            'p2_double_fault_percentage', 'game_duration', 'p1_game_win_rate', 'p2_game_win_rate', 'server_win_rate']

