
import matplotlib.pyplot as plt
import pandas as pd
from scipy.interpolate import splev, splrep
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# 读取数据
data = pd.read_csv('Wimbledon_featured_matches_processed_with_momentums.csv')

# 选择一个match和set进行可视化
selected_match_id = "2023-wimbledon-1701"
selected_set_num = 5
selected_set_data = data[(data['match_id'] == selected_match_id)
& (data['set_no'] == selected_set_num)
 ]

# 设置画布
fig, ax1 = plt.subplots(figsize=(10, 6))

# 添加大标题
fig.suptitle(f"Match: {selected_match_id}, Set: {selected_set_num}", fontsize=16)

# 循环处理每个game
games_in_set = selected_set_data['game_no'].unique()

# 循环处理每个game，绘制折线
for j, game_num in enumerate(games_in_set):
    game_data = selected_set_data[selected_set_data['game_no'] == game_num]
    elapsed_time = game_data['elapsed_time'].apply(lambda x: (pd.to_datetime(x) - pd.to_datetime('00:00:00')).total_seconds())
    score_difference = game_data['p1_score'] - game_data['p2_score']
    
    # 绘制折线
    ax1.plot(elapsed_time, score_difference, label=f'Score Difference {j + 1}')

# 添加灰色虚线
ax1.axhline(y=0, color='gray', linestyle='--', linewidth=1)

ax1.set_xlabel('Elapsed Time (seconds)')
#ax1.set_ylabel('Score Difference')
ax1.legend()

# 创建第二个y轴，用于绘制momentum曲线
ax2 = ax1

# 根据weights计算momentum曲线
weights = [0.1970, 0.2611, 0.4176, 0.1242]  # 请根据实际情况修改权重
momentum_values = selected_set_data[['momentum_1', 'momentum_2', 'momentum_3', 'momentum_4']].values

# 使用np.isnan检查NaN值并用0填充
momentum_values[np.isnan(momentum_values)] = 0

# 将elapsed_time转换为数值类型
numeric_elapsed_time = pd.to_numeric(selected_set_data['elapsed_time'].apply(lambda x: (pd.to_datetime(x) - pd.to_datetime('00:00:00')).total_seconds()))

# 使用spline插值方法
spl = splrep(numeric_elapsed_time, np.dot(momentum_values, weights), k=3)

# 生成更密集的时间点
dense_elapsed_time = pd.Series(np.linspace(numeric_elapsed_time.min(), numeric_elapsed_time.max(), 1000))

# 计算拟合曲线
momentum_curve = splev(dense_elapsed_time, spl)

# 标准化momentum到[-1, 1]范围
scaler = MinMaxScaler(feature_range=(-1, 1))
momentum_curve_normalized = scaler.fit_transform(np.array(momentum_curve).reshape(-1, 1)).flatten()

# 绘制拟合曲线
ax2.plot(dense_elapsed_time, momentum_curve_normalized, color='orange', label='Momentum Curve', linewidth=2)

ax2.set_ylabel('Momentum')
ax2.legend()

# 显示图表
plt.tight_layout(rect=[0, 0.03, 1, 0.95])  # 调整标题位置
# 高亮显示每个momentum数据点并添加文字注记
for i in range(len(dense_elapsed_time)):
    if data['server'].iloc[i] == 1:
        plt.scatter(dense_elapsed_time[i], momentum_curve_normalized[i], color='red', label='P1', s=6, zorder=10)
    elif data['server'].iloc[i] == 2:
        plt.scatter(dense_elapsed_time[i], momentum_curve_normalized[i], color='blue', label='P2', s=6, zorder=10)
        #plt.text(dense_elapsed_time[i], momentum_curve_normalized[i], 'P2', ha='center', va='bottom')

red_patch = plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='red', markersize=10, label='Red: P1 serves')
blue_patch = plt.Line2D([0], [0], marker='o', color='w', markerfacecolor='blue', markersize=10, label='Blue: P2 serves')
ax2.legend(handles=[red_patch, blue_patch, ax2.lines[0], ax2.lines[1]], loc='upper right')

# 让plt默认最大化显示
plt.rcParams['figure.max_open_warning'] = False
manager = plt.get_current_fig_manager()
manager.window.showMaximized()

# 保存图表
plt.savefig('Q1_'+str(selected_set_num)+'.svg')
plt.show()