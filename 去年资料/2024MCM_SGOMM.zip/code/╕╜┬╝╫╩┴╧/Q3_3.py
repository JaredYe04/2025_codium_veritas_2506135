
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from scipy.interpolate import interp1d
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve
import seaborn as sns
import shap
import random

def evaluate_classification_model(model, X_train, y_train, X_test, y_test):
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_proba)

    print(f'Accuracy: {accuracy:.4f}')
    print(f'Precision: {precision:.4f}')
    print(f'Recall: {recall:.4f}')
    print(f'F1 Score: {f1:.4f}')
    print(f'ROC AUC: {roc_auc:.4f}')

    fpr, tpr, thresholds = roc_curve(y_test, y_proba)

    # Rest of the code remains unchanged

def plot_feature_importance(model, X, top_n=None):
    feature_importance = model.feature_importances_
    feature_importance_df = pd.DataFrame({'Feature': X.columns, 'Importance': feature_importance})
    feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)

    if top_n:
        top_n_features = feature_importance_df.head(top_n)
    else:
        top_n_features = feature_importance_df

    top_n_features.to_csv('top_n_features.csv')
    top_n_features['Feature'] = top_n_features['Feature'].apply(lambda x: x[:15]+'...' if len(x) > 15 else x)
    top_n_features['Cumulative_Importance'] = top_n_features['Importance'].cumsum()

    plt.figure(figsize=(12, 6))
    plt.bar(top_n_features['Feature'], top_n_features['Importance'], edgecolor='black', linewidth=0.5)
    plt.xlabel('Feature')
    plt.ylabel('Importance')
    plt.xticks(rotation=0, fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.twinx()
    plt.plot(top_n_features['Feature'], top_n_features['Cumulative_Importance'], color='lightcoral', marker='o', label='Cumulative Importance')
    plt.ylabel('Cumulative Importance', color='lightcoral')
    plt.legend(loc='upper left')

    plt.show()

def analyze_shap_values(model, X, feature_names):
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)

    shap.summary_plot(shap_values, X, feature_names=feature_names)
    plt.show()

def analyze_match_or_set(data, match_id=None, set_number=None, detail=False, comment=False, analyze=False):
    features = [
        # ... (remaining features)
    ]
    target = 'point_victor'

    if match_id:
        match_data = data[data['match_id'] == match_id]
        if set_number and not analyze:
            match_data = match_data[match_data['set_no'] == set_number]
    else:
        match_data = data[data['match_id'] == data['match_id'].iloc[0]]

    match_data['elapsed_time'] = pd.to_timedelta(match_data['elapsed_time']).dt.total_seconds()

    weights = [0.1970, 0.2611, 0.4176, 0.1242]
    match_data['Momentum'] = np.dot(match_data[['momentum_1', 'momentum_2', 'momentum_3', 'momentum_4']], weights)
    scaler = MinMaxScaler(feature_range=(-1, 1))
    match_data['Normalized_Momentum'] = scaler.fit_transform(match_data['Momentum'].values.reshape(-1, 1)).flatten()

    X = match_data[features]
    y = match_data[target]

    X = pd.get_dummies(X)
    y = (y == 1).astype(int)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)

    clf = RandomForestClassifier(n_estimators=100, random_state=42)

    clf.fit(X_train, y_train)

    y_proba = clf.predict_proba(X_test)[:, 1]

    if comment or analyze:
        if not analyze:
            plot_feature_importance(clf, X, top_n=10)
        analyze_shap_values(clf, X_test, features)
        evaluate_classification_model(clf, X_train, y_train, X_test, y_test)

    prediction_df = pd.DataFrame({'Time': X_test['elapsed_time'], 'Probability': y_proba, 'Actual': y_test})

    fpr, tpr, thresholds = roc_curve(y_test, y_proba)

    if analyze:
        return

    best_threshold = 0.5

    prediction_df['Predicted'] = (prediction_df['Probability'] > best_threshold).astype(int)

    match_changes = []
    for i in range(1, len(prediction_df)):
        if prediction_df['Predicted'].iloc[i] != prediction_df['Predicted'].iloc[i - 1]:
            match_changes.append(i)

    prediction_df['P1_Win_Prob'] = prediction_df['Predicted'].rolling(window=10, min_periods=1).mean()
    prediction_df['P2_Win_Prob'] = 1 - prediction_df['P1_Win_Prob']

    interp_func_p1 = interp1d(prediction_df['Time'], prediction_df['P1_Win_Prob'], kind='cubic', fill_value='extrapolate')
    interp_func_p2 = interp1d(prediction_df['Time'], prediction_df['P2_Win_Prob'], kind='cubic', fill_value='extrapolate')

    interp_func_momentum = interp1d(match_data['elapsed_time'], match_data['Momentum'], kind='cubic')

    dense_time = np.linspace(prediction_df['Time'].min(), prediction_df['Time'].max(), 1000)
    p1_win_prob_values = interp_func_p1(dense_time)

    import seaborn as sns
    sns.set_palette("husl")
    cross_points_indices = np.where(p1_win_prob_values > best_threshold)[0]

    from scipy.signal import argrelextrema
    maxima_indices = argrelextrema(p1_win_prob_values, np.greater)[0]
    minima_indices = argrelextrema(p1_win_prob_values, np.less)[0]
    all_extrema_indices = np.concatenate((maxima_indices, minima_indices))

    cross_points_time = dense_time[all_extrema_indices]
    cross_points_prob = p1_win_prob_values[all_extrema_indices]

    score_difference = match_data['p1_score'] - match_data['p2_score']
    score_difference_normalized = scaler.fit_transform(score_difference.values.reshape(-1, 1)).flatten()

    fig = plt.figure(figsize=(12, 6))

    time_range = np.linspace(prediction_df['Time'].min(), prediction_df['Time'].max(), 1000)

    p1_color = '#FF8C65'
    p2_color = '#AED581'
    momentum_color = '#90CAF9'
    diff_color = '#FFD54F'
    star_color = '#748B6F'

    plt.plot(time_range, interp_func_p1(time_range), label='P1 Win Probability (Smoothed)', linewidth=5, color=p1_color, linestyle='-', alpha=1.0)

    if detail:
        plt.plot(time_range, interp_func_p2(time_range), label='P2 Win Probability (Smoothed)', color=p2_color, alpha=1.0, linewidth=3, linestyle='--')

    plt.plot(match_data['elapsed_time'], interp_func_momentum(match_data['elapsed_time']),
             label='Smoothed Momentum', color=momentum_color, linewidth=5, linestyle='-', alpha=1.0)

    if detail:
        plt.plot(match_data['elapsed_time'], score_difference_normalized,
             label='Score Difference (P1 - P2) (Normalized)', color=diff_color, alpha=1.0, linestyle='-', linewidth=2)

    plt.axhline(y=best_threshold, color='gray', linestyle='--', label='Decision Threshold', linewidth=2)

    for i in range(len(cross_points_time)):
        plt.scatter(cross_points_time[i], cross_points_prob[i], color=star_color, marker='*', s=100, zorder=5)

        if i==3 or i ==7:
            plt.annotate(f'T: {cross_points_time[i]:.0f}s\nP: {cross_points_prob[i]:.2f}', 
                 xy=(cross_points_time[i], cross_points_prob[i]), 
                 xytext=(cross_points_time[i] - 150, cross_points_prob[i] + 0.4),
                 arrowprops=dict(arrowstyle='->', linestyle='dashed', color=star_color),
                 color=star_color,
                 fontsize=10,
                 bbox=dict(boxstyle='round,pad=0.3', edgecolor=star_color, facecolor='white'))
    
    plt.gca().set_facecolor('#F0F0F0')
    plt.grid(color='white', linestyle='--', linewidth=0.5)
    plt.gca().spines['top'].set_visible(False)
    plt.gca().spines['right'].set_visible(False)

    plt.xlabel('Elapsed Time (seconds)')
    plt.ylabel('Probability / Smoothed Momentum')
    plt.legend()

    plt.scatter([], [], color=star_color, marker='*', s=200, label='Important Points')
    plt.show()

# Usage example:
data = pd.read_csv("deeply_digged_data.csv")
analyze_match_or_set(data, match_id='2023-wimbledon-1701', set_number=1, detail=False, comment=False, analyze=False)
# or
# analyze_match_or_set(data, match_id='2023-wimbledon-1701')
