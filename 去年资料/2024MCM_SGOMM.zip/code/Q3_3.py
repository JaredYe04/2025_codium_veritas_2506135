import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from scipy.interpolate import interp1d
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
import seaborn as sns
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
import shap
import random

def evaluate_classification_model(model, X_train, y_train, X_test, y_test):
    # ... (省略模型训练部分)

    # 预测测试集
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    # 评估模型性能
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_proba)

    print(f'Accuracy: {accuracy:.4f}')
    print(f'Precision: {precision:.4f}')
    print(f'Recall: {recall:.4f}')
    print(f'F1 Score: {f1:.4f}')
    print(f'ROC AUC: {roc_auc:.4f}')

    # 绘制ROC曲线
    fpr, tpr, thresholds = roc_curve(y_test, y_proba)
    auc_text = f'AUC = {roc_auc:.2f}'

    # 使用 seaborn 风格和颜色
    sns.set(style='darkgrid', palette='muted')

    plt.figure(figsize=(12, 10))

    # 添加背景渐变色
    ax = plt.axes()
    ax.set_facecolor((0.9, 0.9, 0.95))

    # 绘制虚线网格
    plt.grid(color='white', linestyle='--', linewidth=0.5)

    # 动态线宽
    linewidths = np.linspace(1, 5, len(fpr))
    
    # 绘制渐变色填充的曲线
    plt.plot(fpr, tpr, label=f'ROC Curve ({auc_text})', linewidth=2, color='coral')
    plt.fill_between(fpr, tpr, color='coral', alpha=0.3, label='AUC Area', linewidth=2)

    # 添加随机线
    plt.plot([0, 1], [0, 1], linestyle='--', color='gray', linewidth=2, label='Random')

    # 在阴影中间显示AUC的数值
    plt.text(0.5, 0.5, auc_text, ha='center', va='center', fontsize=18, color='black', bbox=dict(facecolor='white', edgecolor='white', boxstyle='round,pad=0.5'))

    # 装饰图表
    plt.xlabel('False Positive Rate', fontsize=16)
    plt.ylabel('True Positive Rate', fontsize=16)
    #plt.title('Dazzling ROC Curve', fontsize=20)
    plt.legend(fontsize=14)

    # 隐藏顶部和右侧的坐标轴
    plt.gca().spines['top'].set_visible(False)
    plt.gca().spines['right'].set_visible(False)

    # 添加星星标记
    plt.scatter([0.2, 0.4, 0.6, 0.8], [0.3, 0.6, 0.7, 0.9], s=100, marker='*', color='purple', label='Important Points')

    plt.show()



def plot_feature_importance(model, X, top_n=None):
    # 获取特征重要性
    feature_importance = model.feature_importances_

    # 创建DataFrame
    feature_importance_df = pd.DataFrame({'Feature': X.columns, 'Importance': feature_importance})

    # 排序DataFrame
    feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)

    if top_n:
        # 选择前N个特征
        top_n_features = feature_importance_df.head(top_n)
    else:
        top_n_features = feature_importance_df

    top_n_features.to_csv('top_n_features.csv')
    # 截断变量名至15个字母内
    top_n_features['Feature'] = top_n_features['Feature'].apply(lambda x: x[:15]+'...' if len(x) > 15 else x)
    # 计算累计贡献率
    top_n_features['Cumulative_Importance'] = top_n_features['Importance'].cumsum()

    # 可视化
    plt.figure(figsize=(12, 6))

    # 绘制条形图（蓝色）
    plt.bar(top_n_features['Feature'], top_n_features['Importance'], edgecolor='black', linewidth=0.5)

    plt.xlabel('Feature')
    plt.ylabel('Importance')
    plt.xticks(rotation=0, fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.5)

    # 绘制累计贡献率曲线（淡红色）
    plt.twinx()
    plt.plot(top_n_features['Feature'], top_n_features['Cumulative_Importance'], color='lightcoral', marker='o', label='Cumulative Importance')
    plt.ylabel('Cumulative Importance', color='lightcoral')
    plt.legend(loc='upper left')

    plt.show()

def analyze_shap_values(model, X, feature_names):
    """
    使用 SHAP Values 分析模型的特征贡献

    参数：
    - model: 训练好的机器学习模型
    - X: 输入数据集
    - feature_names: 特征名称列表

    返回：
    - None
    """
    # 创建 SHAP 解释器
    explainer = shap.TreeExplainer(model)

    # 计算 SHAP 值
    shap_values = explainer.shap_values(X)

    # 可视化平均的 SHAP 值
    shap.summary_plot(shap_values, X, feature_names=feature_names)

    # 如果你想可视化单个样本的 SHAP 值，可以使用下面的代码
    # shap.force_plot(explainer.expected_value, shap_values[0,:], X.iloc[0,:], feature_names=feature_names)

    plt.show()

def analyze_match_or_set(data, match_id=None, set_number=None, detail=False,comment=False,analyze=False):
    # 筛选出需要的特征列
    features = [
        'elapsed_time', 'p1_sets', 'p2_sets', 'p1_games', 'p2_games', 'p1_score', 'p2_score',
        'p1_ace', 'p2_ace', 'p1_winner', 'p2_winner', 'p1_double_fault', 'p2_double_fault',
        'p1_unf_err', 'p2_unf_err', 'p1_net_pt', 'p2_net_pt', 'p1_net_pt_won', 'p2_net_pt_won',
        'p1_break_pt', 'p2_break_pt', 'p1_break_pt_won', 'p2_break_pt_won',
        'p1_distance_run', 'p2_distance_run', 'rally_count', 'speed_mph',
        'serve_width', 'serve_depth', 'return_depth',
        #挖掘后的数据
        'games_diff', 'sets_diff', 'serve_games_diff', 'score_diff', 'p1_win_streak', 'p2_win_streak',
            'key_points_diff', 'p1_first_serve_points_won', 'p2_first_serve_points_won', 'p1_second_serve_points_won',
            'p2_second_serve_points_won', 'p1_ace_percentage', 'p2_ace_percentage', 'p1_double_fault_percentage',
            'p2_double_fault_percentage', 'game_duration', 'p1_game_win_rate', 'p2_game_win_rate', 'server_win_rate'

    ]
    #print(len(features))
    # 选择目标变量
    target = 'point_victor'

    # 根据 match_id 和 set_number 进行筛选
    if match_id:
        match_data = data[data['match_id'] == match_id]
        if set_number and not analyze:
            match_data = match_data[match_data['set_no'] == set_number]
    else:
        # 如果未提供 match_id，默认选择数据的第一场比赛
        match_data = data[data['match_id'] == data['match_id'].iloc[0]]
    
    # 转换 'elapsed_time' 列为秒
    match_data['elapsed_time'] = pd.to_timedelta(match_data['elapsed_time']).dt.total_seconds()

    # 计算加权线性相加的 Momentum 字段
    weights = [0.1970, 0.2611, 0.4176, 0.1242]
    match_data['Momentum'] = np.dot(match_data[['momentum_1', 'momentum_2', 'momentum_3', 'momentum_4']], weights)

    # 标准化 Momentum 字段到 [-1, 1] 范围
    scaler = MinMaxScaler(feature_range=(-1, 1))
    match_data['Normalized_Momentum'] = scaler.fit_transform(match_data['Momentum'].values.reshape(-1, 1)).flatten()

    # 创建特征矩阵 X 和目标变量 y
    X = match_data[features]
    y = match_data[target]


    # 将字符串变量进行独热编码
    X = pd.get_dummies(X)

    # 将目标变量转换为二元分类（1: player 1, 2: player 2）
    y = (y == 1).astype(int)

    # 划分训练集和测试集
    #X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.975 if analyze else 0.3, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)


    # 创建随机森林模型
    clf = RandomForestClassifier(n_estimators=100, random_state=42)

    # 训练模型
    clf.fit(X_train, y_train)

    # 预测概率
    y_proba = clf.predict_proba(X_test)[:, 1]

    if comment or analyze:
        if not analyze:
            plot_feature_importance(clf, X, top_n=10) # 绘制特征重要性图表
        # 评估模型性能
        analyze_shap_values(clf, X_test, features)
        evaluate_classification_model(clf, X_train, y_train, X_test, y_test)

    # 将预测概率和真实标签合并到一个 DataFrame 中
    prediction_df = pd.DataFrame({'Time': X_test['elapsed_time'], 'Probability': y_proba, 'Actual': y_test})

    # 计算真正率、假正率和阈值
    fpr, tpr, thresholds = roc_curve(y_test, y_proba)

    if analyze:
        return

    # 选择最佳阈值
    best_threshold = 0.5

    # 使用最佳阈值对概率进行二元分类
    prediction_df['Predicted'] = (prediction_df['Probability'] > best_threshold).astype(int)

    # 计算每一回合的变化情况
    match_changes = []
    for i in range(1, len(prediction_df)):
        if prediction_df['Predicted'].iloc[i] != prediction_df['Predicted'].iloc[i - 1]:
            match_changes.append(i)

    # 计算 P1 和 P2 的胜率曲线
    prediction_df['P1_Win_Prob'] = prediction_df['Predicted'].rolling(window=10, min_periods=1).mean()
    prediction_df['P2_Win_Prob'] = 1 - prediction_df['P1_Win_Prob']

    # 使用插值法平滑 P1 和 P2 的胜率曲线
    interp_func_p1 = interp1d(prediction_df['Time'], prediction_df['P1_Win_Prob'], kind='cubic', fill_value='extrapolate')
    interp_func_p2 = interp1d(prediction_df['Time'], prediction_df['P2_Win_Prob'], kind='cubic', fill_value='extrapolate')

    # 使用插值法平滑 Momentum 曲线
    interp_func_momentum = interp1d(match_data['elapsed_time'], match_data['Momentum'], kind='cubic')

    # 寻找交点（转折点）在 interp_func_p1 中
    dense_time = np.linspace(prediction_df['Time'].min(), prediction_df['Time'].max(), 1000)
    p1_win_prob_values = interp_func_p1(dense_time)

    import seaborn as sns
    sns.set_palette("husl")
    cross_points_indices = np.where(p1_win_prob_values > best_threshold)[0]

    from scipy.signal import argrelextrema
    # 寻找极大值点
    maxima_indices = argrelextrema(p1_win_prob_values, np.greater)[0]

    # 寻找极小值点
    minima_indices = argrelextrema(p1_win_prob_values, np.less)[0]

    # 合并极大值点和极小值点
    all_extrema_indices = np.concatenate((maxima_indices, minima_indices))

    # 获取对应的时间和概率值
    cross_points_time = dense_time[all_extrema_indices]
    cross_points_prob = p1_win_prob_values[all_extrema_indices]

    # 计算两名选手分数之差并标准化
    score_difference = match_data['p1_score'] - match_data['p2_score']
    score_difference_normalized = scaler.fit_transform(score_difference.values.reshape(-1, 1)).flatten()

    

    fig = plt.figure(figsize=(12, 6))

    time_range = np.linspace(prediction_df['Time'].min(), prediction_df['Time'].max(), 1000)

    # 高级感柔和的高饱和度配色方案
    p1_color = '#FF8C65'
    p2_color = '#AED581'
    momentum_color = '#90CAF9'
    diff_color = '#FFD54F'
    star_color = '#748B6F'

    # 绘制 P1 概率曲线
    plt.plot(time_range, interp_func_p1(time_range), label='P1 Win Probability (Smoothed)', linewidth=5, color=p1_color, linestyle='-', alpha=1.0)

    # 绘制 P2 概率曲线（如果需要）
    if detail:
        plt.plot(time_range, interp_func_p2(time_range), label='P2 Win Probability (Smoothed)', color=p2_color, alpha=1.0, linewidth=3, linestyle='--')

    # 绘制 Momentum 曲线
    plt.plot(match_data['elapsed_time'], interp_func_momentum(match_data['elapsed_time']),
             label='Smoothed Momentum', color=momentum_color, linewidth=5, linestyle='-', alpha=1.0)

    # 绘制 Score Difference 曲线（如果需要）
    if detail:
        plt.plot(match_data['elapsed_time'], score_difference_normalized,
             label='Score Difference (P1 - P2) (Normalized)', color=diff_color, alpha=1.0, linestyle='-', linewidth=2)

    plt.axhline(y=best_threshold, color='gray', linestyle='--', label='Decision Threshold', linewidth=2)
    # 标注转折点及时间戳
    for i in range(len(cross_points_time)):
        plt.scatter(cross_points_time[i], cross_points_prob[i], color=star_color, marker='*', s=100, zorder=5)
        #plt.axvline(x=cross_points_time[i], color=star_color, linestyle='--', linewidth=1, alpha=1.0)

        # 随机选择一些星星进行高亮
        if i==3 or i ==7:
            # 添加标签
            plt.annotate(f'T: {cross_points_time[i]:.0f}s\nP: {cross_points_prob[i]:.2f}', 
                 xy=(cross_points_time[i], cross_points_prob[i]), 
                 xytext=(cross_points_time[i] - 150, cross_points_prob[i] + 0.4),
                 arrowprops=dict(arrowstyle='->', linestyle='dashed', color=star_color),
                 color=star_color,
                 fontsize=10,
                 bbox=dict(boxstyle='round,pad=0.3', edgecolor=star_color, facecolor='white'))
    
    # 设置背景色和网格样式
    plt.gca().set_facecolor('#F0F0F0')
    plt.grid(color='white', linestyle='--', linewidth=0.5)

    # 隐藏顶部和右侧的坐标轴
    plt.gca().spines['top'].set_visible(False)
    plt.gca().spines['right'].set_visible(False)

    plt.xlabel('Elapsed Time (seconds)')
    plt.ylabel('Probability / Smoothed Momentum')
    plt.legend()

    # 调整星星标记的大小
    plt.scatter([], [], color=star_color, marker='*', s=200, label='Important Points')
    plt.show()

# 使用示例：
data = pd.read_csv("deeply_digged_data.csv")  # 替换成你的数据文件路径
analyze_match_or_set(data, match_id='2023-wimbledon-1701', set_number=1,detail=False,comment=False,analyze=False)
# 或
# analyze_match_or_set(data, match_id='2023-wimbledon-1701')