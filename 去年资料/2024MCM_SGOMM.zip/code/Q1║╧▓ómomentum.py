import pandas as pd
import pandas as pd

df1 = pd.read_csv('Wimbledon_featured_matches_processed.csv')
df2 = pd.read_csv('momentums_raw.csv')

merged_df = pd.concat([df1, df2], axis=1)
merged_df.to_csv('Wimbledon_featured_matches_processed_with_momentums.csv', index=False)