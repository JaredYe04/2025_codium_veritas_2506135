import pandas as pd
from datetime import timedelta

# 读取CSV文件
df = pd.read_csv('points.csv')


df['new_score'] = df['score'].str.rsplit(n=1).str[-1]
df[['p1', 'p2']] = df['new_score'].str.split(':', expand=True)
# 定义替换字典
replace_dict = {'0': 0, '15': 1, '30': 2, '40': 3, 'Ad': 4}
# 批量替换值
df['p1'] = df['p1'].replace(replace_dict)
df['p2'] = df['p2'].replace(replace_dict)
df['set_num'] = df['score'].str.split().apply(len)-1
df['game_num'] =df['p1']+df['p2']

print(df)
