import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from scipy.interpolate import interp1d
from sklearn.preprocessing import MinMaxScaler
def plot_normalized_features(features_df, feature_names, scaler, ax):
    for feature_name in feature_names:
        # 选择要显示的特征列
        feature_values = features_df[feature_name]

        # 使用 MinMaxScaler 进行标准化
        normalized_values = scaler.fit_transform(feature_values.values.reshape(-1, 1)).flatten()

        # 使用插值法平滑曲线
        interp_func = interp1d(features_df['elapsed_time'], normalized_values, kind='cubic')

        # 绘制标准化后的曲线
        ax.plot(features_df['elapsed_time'], interp_func(features_df['elapsed_time']),
                label=f'{feature_name} (Normalized)', alpha=0.5)

def analyze_match_or_set(data, match_id=None, set_number=None, detail=False,momentum=True):
    # 筛选出需要的特征列
    features = [
        'elapsed_time', 'p1_sets', 'p2_sets', 'p1_games', 'p2_games', 'p1_score', 'p2_score',
        'p1_ace', 'p2_ace', 'p1_winner', 'p2_winner', 'p1_double_fault', 'p2_double_fault',
        'p1_unf_err', 'p2_unf_err', 'p1_net_pt', 'p2_net_pt', 'p1_net_pt_won', 'p2_net_pt_won',
        'p1_break_pt', 'p2_break_pt', 'p1_break_pt_won', 'p2_break_pt_won',
        'p1_distance_run', 'p2_distance_run', 'rally_count', 'speed_mph',
        'serve_width', 'serve_depth', 'return_depth',
        #挖掘后的数据
        'games_diff', 'sets_diff', 'serve_games_diff', 'score_diff', 'p1_win_streak', 'p2_win_streak',
            'key_points_diff', 'p1_first_serve_points_won', 'p2_first_serve_points_won', 'p1_second_serve_points_won',
            'p2_second_serve_points_won', 'p1_ace_percentage', 'p2_ace_percentage', 'p1_double_fault_percentage',
            'p2_double_fault_percentage', 'game_duration', 'p1_game_win_rate', 'p2_game_win_rate', 'server_win_rate'

    ]

    # 选择目标变量
    target = 'point_victor'

    # 根据 match_id 和 set_number 进行筛选
    if match_id:
        match_data = data[data['match_id'] == match_id]
        if set_number:
            match_data = match_data[match_data['set_no'] == set_number]
    else:
        # 如果未提供 match_id，默认选择数据的第一场比赛
        match_data = data[data['match_id'] == data['match_id'].iloc[0]]
    
    # 转换 'elapsed_time' 列为秒
    match_data['elapsed_time'] = pd.to_timedelta(match_data['elapsed_time']).dt.total_seconds()

    # 计算加权线性相加的 Momentum 字段
    weights = [0.1970, 0.2611, 0.4176, 0.1242]
    match_data['Momentum'] = np.dot(match_data[['momentum_1', 'momentum_2', 'momentum_3', 'momentum_4']], weights)

    # 标准化 Momentum 字段到 [-1, 1] 范围
    scaler = MinMaxScaler(feature_range=(-1, 1))
    match_data['Normalized_Momentum'] = scaler.fit_transform(match_data['Momentum'].values.reshape(-1, 1)).flatten()

    # 创建特征矩阵 X 和目标变量 y
    X = match_data[features]
    y = match_data[target]

    # 将字符串变量进行独热编码
    X = pd.get_dummies(X)

    # 将目标变量转换为二元分类（1: player 1, 2: player 2）
    y = (y == 1).astype(int)

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # 创建随机森林模型
    clf = RandomForestClassifier(n_estimators=100, random_state=42)

    # 训练模型
    clf.fit(X_train, y_train)

    # 预测概率
    y_proba = clf.predict_proba(X_test)[:, 1]

    # 将预测概率和真实标签合并到一个 DataFrame 中
    prediction_df = pd.DataFrame({'Time': X_test['elapsed_time'], 'Probability': y_proba, 'Actual': y_test})

    # 计算真正率、假正率和阈值
    fpr, tpr, thresholds = roc_curve(y_test, y_proba)

    # 选择最佳阈值
    best_threshold = 0.5

    # 使用最佳阈值对概率进行二元分类
    prediction_df['Predicted'] = (prediction_df['Probability'] > best_threshold).astype(int)

    # 计算每一回合的变化情况
    match_changes = []
    for i in range(1, len(prediction_df)):
        if prediction_df['Predicted'].iloc[i] != prediction_df['Predicted'].iloc[i - 1]:
            match_changes.append(i)

    # 计算 P1 和 P2 的胜率曲线
    prediction_df['P1_Win_Prob'] = prediction_df['Predicted'].rolling(window=10, min_periods=1).mean()
    prediction_df['P2_Win_Prob'] = 1 - prediction_df['P1_Win_Prob']

    # 使用插值法平滑 P1 和 P2 的胜率曲线
    interp_func_p1 = interp1d(prediction_df['Time'], prediction_df['P1_Win_Prob'], kind='cubic', fill_value='extrapolate')
    interp_func_p2 = interp1d(prediction_df['Time'], prediction_df['P2_Win_Prob'], kind='cubic', fill_value='extrapolate')

    # 使用插值法平滑 Momentum 曲线
    interp_func_momentum = interp1d(match_data['elapsed_time'], match_data['Momentum'], kind='cubic')

    # 寻找交点（转折点）在 interp_func_p1 中
    dense_time = np.linspace(prediction_df['Time'].min(), prediction_df['Time'].max(), 1000)
    p1_win_prob_values = interp_func_p1(dense_time)
    cross_points_indices = np.where(p1_win_prob_values > best_threshold)[0]

    from scipy.signal import argrelextrema
    # 寻找极大值点
    maxima_indices = argrelextrema(p1_win_prob_values, np.greater)[0]

    # 寻找极小值点
    minima_indices = argrelextrema(p1_win_prob_values, np.less)[0]

    # 合并极大值点和极小值点
    all_extrema_indices = np.concatenate((maxima_indices, minima_indices))

    # 获取对应的时间和概率值
    cross_points_time = dense_time[all_extrema_indices]
    cross_points_prob = p1_win_prob_values[all_extrema_indices]

    # 计算两名选手分数之差并标准化
    score_difference = match_data['p1_score'] - match_data['p2_score']
    score_difference_normalized = scaler.fit_transform(score_difference.values.reshape(-1, 1)).flatten()

    # 绘制概率走势图表
    plt.figure(figsize=(12, 6))
    time_range = np.linspace(prediction_df['Time'].min(), prediction_df['Time'].max(), 1000)
    plt.plot(time_range, interp_func_p1(time_range), label='P1 Win Probability (Smoothed)', color='blue')
    if detail:
        plt.plot(time_range, interp_func_p2(time_range), label='P2 Win Probability (Smoothed)', color='orange', alpha=0.3)
    plt.scatter(prediction_df['Time'], prediction_df['P1_Win_Prob'], label='P1 Win Probability Data Point', color='blue', alpha=0.1)
    if detail:
        plt.scatter(prediction_df['Time'], prediction_df['P2_Win_Prob'], label='P2 Win Probability Data Point', color='orange', alpha=0.1)

    # 绘制 Momentum 曲线
    if momentum:
        plt.plot(match_data['elapsed_time'], interp_func_momentum(match_data['elapsed_time']),
             label='Smoothed Momentum', color='purple')

    # 绘制 Score Difference 曲线
    if detail:
        plt.plot(match_data['elapsed_time'], score_difference_normalized,
             label='Score Difference (P1 - P2) (Normalized)', color='green', alpha=0.4)
    plt.axhline(y=best_threshold, color='red', linestyle='--', label='Decision Threshold')
    plt.annotate('Decision Threshold', (0, 0.5),
                 textcoords="offset points", xytext=(0, 1), ha='center', fontsize=10)

    # 标注转折点及时间戳
    for i in range(len(cross_points_time)):
        plt.scatter(cross_points_time[i], cross_points_prob[i], color='red', marker='o', s=50)
        plt.axvline(x=cross_points_time[i], color='black', linestyle='--', linewidth=1)
        plt.annotate(f'{cross_points_time[i]:.0f} s', (cross_points_time[i]+0.02, cross_points_prob[i]-0.05),
                 textcoords="offset points", xytext=(0, -1), ha='center', fontsize=8)

    #plt.title(f'Flow of Play: Probability Trend Over Time ({match_id}' + (f', Set {set_number}' if set_number else '') + ')')
    plt.xlabel('Elapsed Time (seconds)')
    plt.ylabel('Probability / Smoothed Momentum')


    selected_features = ['games_diff', 'sets_diff', 'serve_games_diff', 'score_diff', 'p1_win_streak', 'p2_win_streak',
            'key_points_diff', 'p1_first_serve_points_won', 'p2_first_serve_points_won', 'p1_second_serve_points_won',
            'p2_second_serve_points_won', 'p1_ace_percentage']  # 选择你想显示的特征列
    selected_features2 =[ 'p2_ace_percentage', 'p1_double_fault_percentage',
            'p2_double_fault_percentage', 'p1_game_win_rate', 'p2_game_win_rate', 'server_win_rate']
    selected_features3 =['p1_sets', 'p2_sets', 'p1_games', 'p2_games', 'p1_score', 'p2_score',
        'p1_ace', 'p2_ace', 'p1_winner', 'p2_winner', 'p1_double_fault', 'p2_double_fault',
        'p1_unf_err', 'p2_unf_err', 'p1_net_pt', 'p2_net_pt', 'p1_net_pt_won', 'p2_net_pt_won',
        'p1_break_pt', 'p2_break_pt', 'p1_break_pt_won', 'p2_break_pt_won',
        'p1_distance_run', 'p2_distance_run', 'rally_count', 'speed_mph']
    
    scaler = MinMaxScaler(feature_range=(-1, 1))

    # 绘制标准化后的特征曲线
    #plot_normalized_features(match_data, selected_features3, scaler, plt.gca())



    plt.legend()
    plt.show()

# 使用示例：
data = pd.read_csv("deeply_digged_data.csv")  # 替换成你的数据文件路径
analyze_match_or_set(data, match_id='2023-wimbledon-1701', set_number=1,detail=False,)
# 或
# analyze_match_or_set(data, match_id='2023-wimbledon-1701')